/*
 ctrl + d = ���� ����
 ctrl + shift + f = �ּ� ����
 */
public class A {
	public static void main(String[] args) {
		System.out.println("Hello java");
		System.out.println("1+2=" + 3);
		System.out.println("1+2=" + 1 + 2);
//		System.out.println("1+2="+1+2);
		System.out.println("1+2=" + (1 + 2));
	}
}
