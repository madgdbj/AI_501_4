
public class E {
	public static void main(String[] args) {
		char a ='a';
		System.out.println("a="+a);
		System.out.println("a="+(int)a);
		
		char A ='A';
		System.out.println("a="+A);
		System.out.println("a="+(int)A);
	}
}
