
public class D {
	public static void main(String[] args) {
		int a = 10;
		double b =20;
		b=a;
		System.out.println("b=" + b);
		
		a=(int)b;
		System.out.println("a="+a);
	}
}
