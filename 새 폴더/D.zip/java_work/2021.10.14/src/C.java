
public class C {
	public static void main(String[] args) {
		int num1;
		int num2 = 10;

		num1 = 20;
		int num3 = num1 + num2;
		System.out.println("num1+num2=" + num3);
		
		byte c = 127;
		c = (byte) (c+1);
		System.out.println("c="+c);
	}
}
