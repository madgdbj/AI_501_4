package chap_03;

public class Ex_05 {
	public static void main(String[] args) {
			
		int rate = 3;
		rate = (int)(3*3.5);
		double double_rate=3*3.5;
		System.out.println("rate = "+ rate);
		System.out.println("double_rate = "+ double_rate);
	}
}
