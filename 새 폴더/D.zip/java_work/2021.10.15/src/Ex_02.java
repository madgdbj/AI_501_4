
public class Ex_02 {
	public static void main(String[] args) {
		
		int a = 10;
		int b = 010;
		int c = 0x10;
		
		System.out.println("a="+a);
		System.out.println("b="+b);
		System.out.println("c="+c);
		
	}
}
