import aa.BankAccount;

public class Ex_07 {
	
	
	public static void main(String[] args) {
				
		BankAccount ref1 = new BankAccount();
		ref1.init("���¹�ȣ 1111", "�ֹι�ȣ 1111", 1000);
		
		BankAccount ref2 = new BankAccount();
		ref2.init("���¹�ȣ 2222", "�ֹι�ȣ 2222", 2000);
		
		ref1.checkyMybal();
		ref2.checkyMybal();
		
	}
	
}
