
public class Ex_04 {
	
	public static int bal = 0;
	
	public static void main(String[] args) {
		deposit(10000);
		checkMybal();
		withdraw(3000);
		checkMybal();
	}
	
	public static int deposit(int num) {
		bal += num;
		return bal;
	}
	
	public static int withdraw(int num) {
		bal -=num;
		return bal;
	}
	
	public static int checkMybal() {
		System.out.println("�ܾ�: "+bal);
		return bal;
	}
}
