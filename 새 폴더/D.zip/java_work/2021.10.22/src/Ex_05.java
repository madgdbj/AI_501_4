import aa.BankAccount;

public class Ex_05 {
	
	public static int bal = 0;
	
	public static void main(String[] args) {
				
		BankAccount a = new BankAccount();
		BankAccount b = new BankAccount();
		
		a.deposit(1000);
		b.deposit(2000);
		
		a.checkyMybal();
		b.checkyMybal();
	}
	
}
