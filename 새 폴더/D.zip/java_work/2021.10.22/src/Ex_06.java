import aa.BankAccount;

public class Ex_06 {
	
	public static int bal = 0;
	
	public static void main(String[] args) {
				
		BankAccount ref1 = new BankAccount();
		BankAccount ref2 = ref1;
		
		
		ref1.deposit(1000);
		ref2.checkyMybal();
		
		ref2.deposit(1000);
		ref1.checkyMybal();
		
//		check(ref1);
		System.out.println("acc���� �ٲ�");
		
		ref1.checkyMybal();
		ref2.checkyMybal();
		
		ref1 = null;
		if(ref1 == null) {
			
		}
	}
	
}
