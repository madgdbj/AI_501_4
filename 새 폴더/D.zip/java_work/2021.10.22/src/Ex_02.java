import aa.A;

public class Ex_02 {
	public static void main(String[] args) {
		A a = new A();
		a.fact(11);
		
//		System.out.println(a.a);
	}
	
}
