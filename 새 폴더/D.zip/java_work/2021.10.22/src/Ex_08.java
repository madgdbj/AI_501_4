import aa.BankAccount;

public class Ex_08 {
	
	
	public static void main(String[] args) {
				
		BankAccount a1 = new BankAccount("���¹�ȣ 1111", "�ֹι�ȣ 1111", 1000);
		BankAccount a2 = new BankAccount("���¹�ȣ 2222", "�ֹι�ȣ 2222", 2000);
		
		a1.checkyMybal();
		a2.checkyMybal();
	}
	
}
