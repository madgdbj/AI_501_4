import aa.BB;

public class Ex_06 {
	
	public static void main(String[] args) {
		BB b1 = new BB();
		
		System.out.println(b1.doB());
		System.out.println(b1.doC());
		b1.doD(3);
	}
	
}
