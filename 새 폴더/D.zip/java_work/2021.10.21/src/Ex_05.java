//import aa.AA;

public class Ex_05 {
	
	public static void main(String[] args) {
		AA a1 = new AA();
//		a1.doA();
		System.out.println("����");
		a1.hi(14, 145);
		a1.bye();
		System.out.println("��");
	}
	
}
