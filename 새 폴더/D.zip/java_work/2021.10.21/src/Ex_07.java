import aa.BB;

public class Ex_07 {
	
	public static void main(String[] args) {
		int a =10;
		if (a==10) {
			int num=20;
			System.out.println("num= " + num);
		}
		
		System.out.println("a= " + a);
		{
			int b =20;
			int aa=30;
		}
	}
	
}
