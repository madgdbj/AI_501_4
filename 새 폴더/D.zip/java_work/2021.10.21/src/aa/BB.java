package aa;

public class BB {

	public void doA() {
		
	}
	
	public int doB() {
		return (int)1.2;
		
	}
	
	public double doC() {
		return 1;
	}
	
	public void doD(int a) {
		System.out.println("���");
		if(a==1) {
			return;
		}
		else {
			System.out.println("a�� 1�� �ƴϴ�");
		}
		
	}
}
