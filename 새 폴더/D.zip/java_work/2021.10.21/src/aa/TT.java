package aa;

public class TT {

	public void doA(int a, int b) {
		System.out.println(a + "+" + b + ": " + (a + b));
		System.out.println(a + "-" + b + ": " + (a - b));
		System.out.println(a + "*" + b + ": " + (a * b));
		System.out.println(a + "/" + b + ": ��=" + (a / b) + " ������=" + (a % b));
	}

	public void doB(int a, int b) {
		int c = a - b;

		if (c < 0) {
			c *= -1;
		}

		System.out.println("�� ���� ���� ���밪: " + c);

	}
	
	public void doC(int a) {
		
		double b = (2*a)*3.14;
		double c = (a*a)*3.14;;

		System.out.println("���� ����: " + b + "���� �ѷ�: " + c);

	}
	
public void doD(int a) {
	
		int count = 0;
		for (int i = 1; i <= a; i++) {
			int b = a%i;
			
			if(b==0) {
				count++;
			}
			
		}
		
		if(count == 2) {
			System.out.println("true");
		}
		else if(count == 1){
			System.out.println("1�� ����");
		}
		else{
			System.out.println("false");
		}
		
	}
}
