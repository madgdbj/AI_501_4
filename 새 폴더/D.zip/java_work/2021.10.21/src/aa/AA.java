package aa;

public class AA {

	public void doA() {
		System.out.println("doA");
	}
}
