
public class Ex_03 {
	public static void main(String[] args) {
	
		
		for (int A = 0; A <= 9; A++) {
			for (int B = 0; B <= 9; B++) {
				if((A+B) == 9) {
					System.out.println("A:"+A + " "
							+ "B:"+B );
				}
			}
		}
	}
}
