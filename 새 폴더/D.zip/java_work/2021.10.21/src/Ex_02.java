
public class Ex_02 {
	public static void main(String[] args) {
		
		for (int dan = 2; dan <9; dan+=2) {
			
			for (int i = 1; i < dan+1; i++) {
				
				System.out.println(dan + "X" + i + "=" + (dan*i)+"\t");
			}
			System.out.println();
		}
	}
}
