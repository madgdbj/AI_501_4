
public class Ex_08 {
	public static void main(String[] args) {
		int num1 = 10;
		boolean sta = true;
		
		if(sta) {
//			int num1 = 20;
			System.out.println("num1 = " + num1);
		}
		
		{
			int num2 = 30;
			System.out.println("num2 = " + num2);
		}
		
		System.out.println("num1 = " + num1);
//		System.out.println("num2 = " + num2);
		
	}
}
