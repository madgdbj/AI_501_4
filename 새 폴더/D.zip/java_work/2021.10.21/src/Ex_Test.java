import aa.TT;

public class Ex_Test {
	public static void main(String[] args) {

		TT t1 = new TT();

		t1.doA(100, 4);

		t1.doB(4, 100);
		
		t1.doC(4);
		
		t1.doD(137);
		
		System.out.println("------");
		
		
		int count = 0;
		
		for(int a = 1; a <= 100; a++) {
		
			count = 0;
			
		for (int i = 1; i <= a; i++) {
			int b = a%i;
			
			if(b==0) {
				count++;
			}
		}
		
		if(count == 2) {
			System.out.println(a);
		}
		
		}
		
	}
}
