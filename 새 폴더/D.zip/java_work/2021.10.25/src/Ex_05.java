import javax.swing.JFrame;

public class Ex_05 {
	public static void main(String[] args) {
		
		JFrame jf = new JFrame();
		jf.setSize(600,400);
		jf.setVisible(true);
		jf.setDefaultCloseOperation(jf.EXIT_ON_CLOSE);
		
	}
}
