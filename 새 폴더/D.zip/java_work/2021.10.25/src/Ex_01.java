import java.util.Scanner;

import aa.Exam;

public class Ex_01 {
	public static void main(String[] args) {
		Exam ex = new Exam();
		Scanner scan = new Scanner(System.in);

		while (true) {
			System.out.println("����� ���ϳ�?");
			int inputNum = scan.nextInt();
			int result = ex.exam01(inputNum);

			if (inputNum == -1) {
				System.out.println("����");
				break;
			} else {
				System.out.println("result = " + result);
			}

		}

	}
}
