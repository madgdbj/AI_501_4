package aa;

public class Triangle {

	int base; // �غ�
	int heights; // ����

	public Triangle(int b, int h) {
		base = b;
		heights = h;
	}

	public double traArea() {
		return (double) base * heights / 2;
	}
}
