import java.util.Scanner;

import aa.Exam;

public class Ex_02 {

	public static void main(String[] args) {

		Exam ex = new Exam();
		Scanner scan = new Scanner(System.in);
		System.out.println("���� �Է�:");
		int inputIum = scan.nextInt();
		String result = ex.exam02(inputIum);
		System.out.println("result = " + result);

	}
}
