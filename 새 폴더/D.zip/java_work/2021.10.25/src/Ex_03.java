import aa.Triangle;

public class Ex_03 {
	public static void main(String[] args) {
		Triangle t1 = new Triangle(5, 3);

		double result = t1.traArea();

		System.out.println("���� = " + result);
	}
}
