import aa.AA;

public class Ex_05 {
	public static void main(String[] args) {
		
		AA a1 = new AA();
		a1.doB(100);
		a1.doB(51);
		a1.doB(-100);
	}
}
