import aa.AA;

public class Ex_06 {
	public static void main(String[] args) {
		
		AA a1 = new AA();
		a1.doC(10, 5);
		a1.doC(5, 10);
		a1.doC(5, 12);
	}
}
