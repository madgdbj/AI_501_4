import aa.BB;

public class Ex_07 {
	public static void main(String[] args) {
		
		BB b1 = new BB();
		
		//b1.doA();
		
		//b1.doB();
		
		b1.doC(3);
	}
}
