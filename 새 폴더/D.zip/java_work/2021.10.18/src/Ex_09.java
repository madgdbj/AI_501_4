import java.util.Scanner;

import aa.DD;

public class Ex_09 {
	public static void main(String[] args) {
		System.out.println("�����Է�");
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();

		DD d1 = new DD();
		d1.doA(num);
	}
}
