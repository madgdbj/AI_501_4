import java.util.Scanner;

import aa.TT;

public class Ex_Test {
	
	public static void main(String[] args) {
		
		TT a1 = new TT();
		
		//a1.doA(100);
		
		//a1.doB(1, 99);
		
		//a1.doC(1, 100);
		
		//a1.doD(2, 7);
		
		//a1.doE(1, 10);
		
		//a1.doF(5);
		
	}
}
