package aa;

public class TT {
	public static void main(String[] args) {
	}

	public void doA(int num) {

		if (num > 0 && (num % 2) == 0) {
			System.out.println("����̸鼭 ¦��");
		}

		else {
			System.out.println("����");
		}
	}

	public void doB(int num, int max) {
		int hap = 0;

		do {
			hap = hap + num;
			num++;
		} while (num <= max);
		System.out.println("hap = " + hap);
	}

	public void doC(int num, int max) {
		int st = num;

		while (num < max + 1) {
			System.out.println(num);
			num++;
		}

		System.out.println("-----------");

		do {
			System.out.println(max);
			max--;
		} while (st <= max);
	}

	public void doD(int num1, int num2) {
		int st = 1;
		int max = 1000;
		int hap = 0;

		while (st < max) {

			if ((st % num1 == 0) && (st % num2 == 0)) {
				System.out.println(st);
				hap = hap + st;
			}
			st++;
		}

		System.out.println(hap);
	}

	public void doE(int num1, int num2) {

		int st = 1;

		for (int i = num1; i <= num2; i++) {
			st *= num1;
			num1++;
		}
		
		System.out.println(st);

	}
	
	public void doF(int num) {


		for (int i = 1; i <= 9; i++) {
			
			System.out.println(num + "*" + i + "=" + num * i);
			
		}

	}
}
