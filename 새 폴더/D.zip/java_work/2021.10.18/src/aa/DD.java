package aa;

import java.util.Scanner;

public class DD {

	// break;
	public void doA(int num) {
		System.out.println("�Է¹��� ���� " + num);

		for (int i = 1; i < 10; i++) {
			System.out.println(num + "*" + i + "=" + num * i);
		}
	}
}
