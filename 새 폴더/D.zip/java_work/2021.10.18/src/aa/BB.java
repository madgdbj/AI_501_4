package aa;

import java.util.Iterator;

public class BB {

	public void doA() {

		int n = 3;
		switch (n) {
		case 1:
			System.out.println("1111111");
		case 2:
			System.out.println("2222222");
		case 3:
			System.out.println("3333333");
		case 4:
			System.out.println("4444444");
		default:
			System.out.println("����Ʈ..");
		}

	}

	public void doB() {

		int num1 = 0;
		while (num1 < 5) {
			System.out.println("num1 = " + num1);
			num1++;
		}

	}
	
	public void doC(int num1) {
		for (; num1 < 5; num1++) {
			System.out.println("num1 = " +num1);
		}
	}
}
