import aa.BB;
import aa.CC;

public class Ex_08 {
	public static void main(String[] args) {
		
		CC c1 = new CC();
		//c1.doA();
		//c1.doB();
		c1.doC(4,6);
		
	}
}
