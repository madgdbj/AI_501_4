import java.util.Scanner;

import aa.AA;

public class Ex_04 {
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("���� �Է�: ");
		int a = scan.nextInt();
		System.out.println("a = "+a);
		
		AA a1 = new AA();
	}
}
